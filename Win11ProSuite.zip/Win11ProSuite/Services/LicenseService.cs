using System.Net.Http;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Win32;

namespace Win11ProSuite.Services;

public sealed record LicenseResult(bool IsValid, string Message, string? LicensedTo = null);

/// <summary>
/// Gumroad license activation. The key is verified over HTTPS, then cached in
/// %AppData%\Win11ProSuite\license.dat, encrypted with Windows DPAPI (current user + machine entropy).
/// A cached license is re-verified online at most weekly, with a 14-day offline grace period.
/// </summary>
public sealed class LicenseService
{
    private const string VerifyUrl = "https://api.gumroad.com/v2/licenses/verify";

    private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(15) };
    private static readonly TimeSpan RecheckInterval = TimeSpan.FromDays(7);
    private static readonly TimeSpan OfflineGrace = TimeSpan.FromDays(14);

    /// <summary>Gumroad product ID, injected at build time via -p:GumroadProductId=...</summary>
    public static string ProductId { get; } =
        typeof(LicenseService).Assembly
            .GetCustomAttributes<AssemblyMetadataAttribute>()
            .FirstOrDefault(a => a.Key == "GumroadProductId")?.Value?.Trim() ?? string.Empty;

    public string LicensePath => Path.Combine(AppPaths.DataDirectory, "license.dat");

    // ------------------------------------------------------------------ public API

    public async Task<LicenseResult> ActivateAsync(string licenseKey, CancellationToken cancellationToken = default)
    {
        string key = licenseKey.Trim();
        if (key.Length == 0)
        {
            return new LicenseResult(false, "Enter the license key from your purchase receipt.");
        }

        Outcome outcome = await VerifyAsync(key, incrementUses: true, cancellationToken);
        if (!outcome.Valid)
        {
            return new LicenseResult(false, outcome.Message);
        }

        var record = new LicenseRecord
        {
            Key = key,
            MachineId = GetMachineId(),
            ActivatedUtc = DateTime.UtcNow,
            LastVerifiedUtc = DateTime.UtcNow,
            Email = outcome.Email
        };

        try
        {
            Save(record);
        }
        catch (Exception ex)
        {
            return new LicenseResult(false, $"The key is valid, but it couldn't be saved on this PC: {ex.Message}");
        }

        return new LicenseResult(true, "Activated.", outcome.Email);
    }

    public async Task<LicenseResult> ValidateStoredAsync(CancellationToken cancellationToken = default)
    {
        LicenseRecord? record = Load();
        if (record is null)
        {
            return new LicenseResult(false, string.Empty);
        }

        if (!string.Equals(record.MachineId, GetMachineId(), StringComparison.Ordinal))
        {
            Delete();
            return new LicenseResult(false, "This license was activated on a different PC. Please activate again.");
        }

        DateTime sinceVerified = record.LastVerifiedUtc;
        if (DateTime.UtcNow - sinceVerified < RecheckInterval)
        {
            return new LicenseResult(true, "Licensed.", record.Email);
        }

        Outcome outcome = await VerifyAsync(record.Key, incrementUses: false, cancellationToken);

        if (outcome.Reachable)
        {
            if (outcome.Valid)
            {
                record.LastVerifiedUtc = DateTime.UtcNow;
                try { Save(record); } catch { /* still valid this session */ }
                return new LicenseResult(true, "Licensed.", record.Email);
            }

            Delete();
            return new LicenseResult(false, $"Your license is no longer valid: {outcome.Message}");
        }

        // Couldn't reach Gumroad: allow a grace period so the app keeps working offline.
        if (DateTime.UtcNow - sinceVerified <= RecheckInterval + OfflineGrace)
        {
            return new LicenseResult(true, "Licensed (offline).", record.Email);
        }

        return new LicenseResult(false, "Please connect to the internet so your license can be re-verified.");
    }

    // ------------------------------------------------------------------ Gumroad

    private sealed record Outcome(bool Reachable, bool Valid, string Message, string? Email);

    private static async Task<Outcome> VerifyAsync(string key, bool incrementUses, CancellationToken cancellationToken)
    {
        if (ProductId.Length == 0)
        {
            return new Outcome(false, false,
                "This build was published without a Gumroad product ID. Rebuild with -p:GumroadProductId=<your id>.", null);
        }

        try
        {
            using var content = new FormUrlEncodedContent(new Dictionary<string, string>
            {
                ["product_id"] = ProductId,
                ["license_key"] = key,
                ["increment_uses_count"] = incrementUses ? "true" : "false"
            });

            using HttpResponseMessage response = await Http.PostAsync(VerifyUrl, content, cancellationToken);

            if ((int)response.StatusCode >= 500)
            {
                return new Outcome(false, false, "The license server is having problems. Please try again shortly.", null);
            }

            string json = await response.Content.ReadAsStringAsync(cancellationToken);
            using JsonDocument document = JsonDocument.Parse(json);
            JsonElement root = document.RootElement;

            bool success = root.TryGetProperty("success", out JsonElement successElement)
                           && successElement.ValueKind == JsonValueKind.True;

            if (!success)
            {
                string message = root.TryGetProperty("message", out JsonElement messageElement)
                                 && messageElement.ValueKind == JsonValueKind.String
                    ? messageElement.GetString() ?? "That license key isn't valid."
                    : "That license key isn't valid.";
                return new Outcome(true, false, message, null);
            }

            string? email = null;
            if (root.TryGetProperty("purchase", out JsonElement purchase) && purchase.ValueKind == JsonValueKind.Object)
            {
                if (Flag(purchase, "refunded")) return new Outcome(true, false, "This purchase was refunded.", null);
                if (Flag(purchase, "chargebacked")) return new Outcome(true, false, "This purchase was charged back.", null);
                if (Flag(purchase, "disputed") && !Flag(purchase, "dispute_won"))
                {
                    return new Outcome(true, false, "This purchase is under dispute.", null);
                }
                if (HasValue(purchase, "subscription_ended_at") || HasValue(purchase, "subscription_failed_at"))
                {
                    return new Outcome(true, false, "The subscription for this license has ended.", null);
                }

                if (purchase.TryGetProperty("email", out JsonElement emailElement) && emailElement.ValueKind == JsonValueKind.String)
                {
                    email = emailElement.GetString();
                }
            }

            return new Outcome(true, true, "Valid.", email);
        }
        catch (HttpRequestException)
        {
            return new Outcome(false, false, "Couldn't reach the license server. Check your internet connection and try again.", null);
        }
        catch (TaskCanceledException) when (!cancellationToken.IsCancellationRequested)
        {
            return new Outcome(false, false, "The license server took too long to respond. Please try again.", null);
        }
        catch (JsonException)
        {
            return new Outcome(false, false, "The license server returned an unexpected response.", null);
        }
    }

    private static bool Flag(JsonElement element, string name)
        => element.TryGetProperty(name, out JsonElement value) && value.ValueKind == JsonValueKind.True;

    private static bool HasValue(JsonElement element, string name)
        => element.TryGetProperty(name, out JsonElement value)
           && value.ValueKind != JsonValueKind.Null
           && value.ValueKind != JsonValueKind.Undefined;

    // ------------------------------------------------------------------ DPAPI storage

    private sealed class LicenseRecord
    {
        public string Key { get; set; } = string.Empty;
        public string MachineId { get; set; } = string.Empty;
        public DateTime ActivatedUtc { get; set; }
        public DateTime LastVerifiedUtc { get; set; }
        public string? Email { get; set; }
    }

    private void Save(LicenseRecord record)
    {
        byte[] plain = JsonSerializer.SerializeToUtf8Bytes(record);
        byte[] protectedBytes = ProtectedData.Protect(plain, GetEntropy(), DataProtectionScope.CurrentUser);

        string temp = LicensePath + ".tmp";
        File.WriteAllBytes(temp, protectedBytes);
        File.Move(temp, LicensePath, overwrite: true);
    }

    private LicenseRecord? Load()
    {
        try
        {
            if (!File.Exists(LicensePath)) return null;

            byte[] protectedBytes = File.ReadAllBytes(LicensePath);
            byte[] plain = ProtectedData.Unprotect(protectedBytes, GetEntropy(), DataProtectionScope.CurrentUser);
            return JsonSerializer.Deserialize<LicenseRecord>(plain);
        }
        catch
        {
            // Corrupt, or encrypted by another Windows user/machine: treat as not activated.
            return null;
        }
    }

    private void Delete()
    {
        try { if (File.Exists(LicensePath)) File.Delete(LicensePath); } catch { }
    }

    private static byte[] GetEntropy()
        => SHA256.HashData(Encoding.UTF8.GetBytes("Win11ProSuite|license|" + GetMachineId()));

    private static string GetMachineId()
    {
        try
        {
            using RegistryKey baseKey = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64);
            using RegistryKey? key = baseKey.OpenSubKey(@"SOFTWARE\Microsoft\Cryptography");
            if (key?.GetValue("MachineGuid") is string guid && guid.Length > 0) return guid;
        }
        catch
        {
            // Fall through.
        }

        return Environment.MachineName;
    }
}
