using System.Windows;
using System.Windows.Input;
using Win11ProSuite.Services;

namespace Win11ProSuite;

/// <summary>First-launch (or revoked-license) gate. Closes with DialogResult = true once activated.</summary>
public partial class ActivationWindow : Window
{
    private readonly LicenseService _license;

    public LicenseResult? Result { get; private set; }

    public ActivationWindow(LicenseService license, string? notice = null)
    {
        InitializeComponent();
        _license = license;

        if (!string.IsNullOrWhiteSpace(notice))
        {
            ShowError(notice);
        }

        Loaded += (_, _) => KeyBox.Focus();
    }

    private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ButtonState == MouseButtonState.Pressed)
        {
            try { DragMove(); } catch (InvalidOperationException) { }
        }
    }

    private async void KeyBox_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter && ActivateButton.IsEnabled)
        {
            e.Handled = true;
            await ActivateAsync();
        }
    }

    private async void Activate_Click(object sender, RoutedEventArgs e) => await ActivateAsync();

    private void Quit_Click(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
    }

    private async Task ActivateAsync()
    {
        string key = KeyBox.Text.Trim();
        if (key.Length == 0)
        {
            ShowError("Enter the license key from your purchase receipt.");
            return;
        }

        SetBusy(true);
        LicenseResult? result = null;
        try
        {
            result = await _license.ActivateAsync(key);
        }
        catch (Exception ex)
        {
            ShowError($"Activation failed: {ex.Message}");
        }
        finally
        {
            SetBusy(false);
        }

        if (result is null) return;

        if (result.IsValid)
        {
            Result = result;
            DialogResult = true;
        }
        else
        {
            ShowError(result.Message);
        }
    }

    private void SetBusy(bool busy)
    {
        Busy.Visibility = busy ? Visibility.Visible : Visibility.Collapsed;
        ActivateButton.IsEnabled = !busy;
        KeyBox.IsEnabled = !busy;
        if (busy) ErrorText.Visibility = Visibility.Collapsed;
    }

    private void ShowError(string message)
    {
        ErrorText.Text = message;
        ErrorText.Visibility = Visibility.Visible;
    }
}
